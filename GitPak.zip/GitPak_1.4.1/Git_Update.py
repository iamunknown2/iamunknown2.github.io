# This Python code is for updating your Github repository via Git (the easier way)
import os
try: input = raw_input
except NameError: pass
print("Please make sure that git is installed!")
print("Your cloned repository will be stored in where the Git_Update file is located.")
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
answer1 = input("Please specify your username: ")
clearscreen()
answer2 = input("Please specify your repository name: ")
clearscreen()
parentfolder = ".."
os.chdir(parentfolder)
command1 = "git clone https://github.com/" + answer1 + "/" + answer2
os.system(command1)
clearscreen()
print("Please place your files in the name of your repository, where your Git_Update is located as well.")
input("Hit RETURN/Enter to continue: ")
os.chdir(answer2)
os.system("git add -A")
clearscreen()
answer3 = input("Enter update notes (commit messages) here. Default commit message is \"Update\": ")
if answer3 == "":
	command3 = "git commit -a -m \"Update\""
else:
	command3 = "git commit -a -m \"" + answer3 + "\""
os.system(command3)
clearscreen()
answer4 = input("What branch do you want to send/push your updates to? If you don't know what branches are, leave it blank: ")
clearscreen()
if answer4 == "":
	command4 = "git push -u origin master"
else:
	command4 = "git push -u origin " + answer3
os.system(command4)
clearscreen()
input("The code push/upload has finished. Hit Enter/Return to exit this program now: ")
raise SystemExit
