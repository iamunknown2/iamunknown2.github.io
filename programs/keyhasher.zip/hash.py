try: input = raw_input
except NameError: pass
answer = input("Specify input to hash: ")
hashed = (int(answer) ** len(str(answer))) % 954606551
print("Hashed outcome: " + str(hashed))
input("Hit Enter/Return to exit this program now: ")
