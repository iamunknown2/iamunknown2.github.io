import os
try: input = raw_input
except NameError: pass
print("Please make sure that git is installed!")
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
cfg_file = open("config.txt", "r")
lines = cfg_file.readlines()
if (lines[0].strip() == "1"):
	config = 1
else:
	config = 0
cfg_file.close()
if (config == 0):
	username = input("Please specify default username (ignore if you don't want default username): ")
else:
	username = lines[1].strip()
input("Username config has finished. Hit Enter/Return to exit this program now: ")
