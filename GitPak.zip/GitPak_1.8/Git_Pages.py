# This Python Code is for adding pages to your Github website (the easier way) 
import os
try: input = raw_input
except NameError: pass
print("Please make sure that git is installed!")
print("Please make sure that your repository name is username.github.io.")
print("Your repository will be stored in the directory the GitPak folder is located.")
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
answer1 = input("Please specify your username: ")
parentfolder = ".."
os.chdir(parentfolder)
repo = answer1 + ".github.io"
command1 = "git clone https://github.com/" + answer1 + "/" + repo
os.chdir(repo)
os.system(command1)
clearscreen()
answer2 = input("Please specify the name of your page: ")
os.chdir(repo)
os.mkdir(answer2)
clearscreen()
print("Drop your files in the directory " + answer2 + " which will be in" + repo + ".")
os.chdir(answer2)
os.system("git add -A")
clearscreen()
answer3 = input("Enter update notes (commit messages) here. Default commit message is \"Update\": ")
if answer3 == "":
	command2 = "git commit -a -m \"Update\""
else:
	command2 = "git commit -a -m \"" + answer2 + "\""
os.system(command2)
clearscreen()
answer4 = input("What branch do you want to send/push your updates to? If you don't know what branches are, leave it blank: ")
clearscreen()
if answer4 == "":
	command3 = "git push -u origin master"
else:
	command3 = "git push -u origin " + answer2
os.system(command3)
clearscreen()
print("Your page can be edited in the folder" + answer2 + ", which in turn can be found in the directory " + repo + ".")
input("Your page can be seen at " + repo + "/" + answer2 + ". Hit Enter/Return to exit this program now: ")
raise SystemExit
