#include <stdio.h>
#include <stdlib.h>
int main() {
	int i = 1;
	int is_prime;
	int t;
	int answer;
	int *primes;
	int prime_count = 1;
	printf("Enter n (for nth prime): ");
	scanf("%d", &answer);
	primes = malloc(answer * sizeof(int));
	primes[0] = 2;
	if (answer == 1) {
		printf("\nPrime 1: 2");
		exit(0);
	}
	printf("\nPrime 1: 2");
	while(1) {
		i += 2;
		is_prime = 1;
		for (t = 0; t < answer; t++) {
			if (primes[t] == NULL) {
				break;
			}
			if (primes[t] * primes[t] > i) {
				break;
			}
			if (i % primes[t] == 0) {
				is_prime = 0;
				break;
			}
		}
		if (is_prime == 1) {
			primes[prime_count] = i;
			++prime_count;
			printf("\nPrime %d: %d", prime_count, i);
		}
		if (prime_count == answer) {
			break;
		}
	}
	return 0;
}
