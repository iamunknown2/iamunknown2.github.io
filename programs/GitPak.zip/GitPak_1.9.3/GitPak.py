#!/usr/bin/env python
# This python code is for starting up the pagemaker/updater/branch-manager. 
import os
try: input = raw_input
except NameError: pass
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
clearscreen
command = ""
while True:
	answer = input("Input 'u' to start repository updater, 'p' to start page adder, 'b' to start branch-manager or 'c' to start Git config: ")
	if (answer.lower() == u or answer.lower() == p or answer.lower() == b or answer.lower() == c):
		break
	print("Error! Answer invalid.")
if (os.name == "windows"):
	if (answer == "u" or answer == "U"):
		command = "python Git_Update.py"
		clearscreen()
		os.system(command)
	elif (answer == "p" or answer == "P"):
		command = "python Git_Pages.py"
		clearscreen()
		os.system(command)
	elif (answer == "b" or answer == "B"):
		command = "python Git_Branch.py"
		clearscreen()
		os.system(command)
elif (os.name == "posix"):
	if (answer == "u" or answer == "U"):
		command = "python ./Git_Update.py"
		clearscreen()
		os.system(command)
	elif (answer == "p" or answer == "P"):
		command = "python ./Git_Pages.py"
		clearscreen()
		os.system(command)
	elif (answer == "b" or answer == "B"):
		command = "python ./Git_Branch.py"
		clearscreen()
		os.system(command)
raise SystemExit
