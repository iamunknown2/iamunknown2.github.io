import os
def findos:
	if (os.name == "windows"):
		os = "w"
	elif (os.name == "posix"):
		os = "p"
try: input = raw_input
except NameError: pass
answer1 = input("Please specify your username: ")
answer2 = input("Please specify the repository you want to download: ")
answer3 = input("Please specify the branch of your source. Leave it blank if you don't know what branches are: ")
if (answer3 == ""):
	answer3 = "master.zip"
if (os == "w"):
	command = "(new-object System.Net.WebClient).DownloadFile(" + "https://www.github.com/" + answer1 + "/" + answer2 + "/" + answer3 + ", " + "../" + answer3 + ")"
elif (os == "p"):
	command = "wget " + "https://www.github.com/" + answer1 + "/" + answer2 + "/" + answer3 + " -P .."
