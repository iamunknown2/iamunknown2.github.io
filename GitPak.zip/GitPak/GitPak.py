# This Python Code is for starting up the pagemaker/updater. 
import os
try: input = raw_input
except NameError: pass
command = ""
cls = "cls"
clear = "clear"
answer = input("Input 'u' to start repository updater, 'p' to start page adder: ")
if (os.name == "windows"):
	if (answer == "u" or answer == "U"):
		command = "python Git_Update.py"
		os.system(cls)
		os.system(command)
	elif (answer == "p" or answer == "P"):
		command = "python Git_Pages.py"
		os.system(cls)
		os.system(command)
	else:
		input("Sorry! Your message couldn't be processed. Hit \"Return\" or \"Enter\" to exit this program: ")
elif (os.name == "posix"):
	if (answer == "u" or answer == "U"):
		command = "python ./Git_Update.py"
		os.system(clear)
		os.system(command)
	elif (answer == "p" or answer == "P"):
		os.system(clear)
		command = "python ./Git_Update.py"
		os.system(command)
	else:
		input("Sorry! Your message couldn't be processed. Hit \"Return\" or \"Enter\" to exit this program: ")
raise SystemExit
