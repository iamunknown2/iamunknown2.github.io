try: input = raw_input
except NameError: pass
answer = int(input("Specify input to crack: "))
i = 0
while True:
	i += 1
	if ((int(i) ** len(str(i))) % 954606551) == answer:
		break
print("First answer: " + str(i))
input("Hit Enter/Return to exit this program now: ")
