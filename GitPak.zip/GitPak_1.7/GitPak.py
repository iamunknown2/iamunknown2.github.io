# This Python Code is for starting up the pagemaker/updater. 
import os
try: input = raw_input
except NameError: pass
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
clearscreen
command = ""
answer = input("Input 'u' to start repository updater, 'p' to start page adder and 'u' to start source downloader: ")
if (os.name == "windows"):
	if (answer == "u" or answer == "U"):
		command = "python Git_Update.py"
		clearscreen()
		os.system(command)
	elif (answer == "p" or answer == "P"):
		command = "python Git_Pages.py"
		clearscreen()
		os.system(command)
	elif (answer == "s" or answer == "S"):
		command = "python Git_Source.py"
		clearscreen()
		os.system(command)
	else:
		input("Sorry! Your message couldn't be processed. Hit \"Return\" or \"Enter\" to exit this program: ")
elif (os.name == "posix"):
	if (answer == "u" or answer == "U"):
		command = "python ./Git_Update.py"
		clearscreen()
		os.system(command)
	elif (answer == "p" or answer == "P"):
		command = "python ./Git_Pages.py"
		clearscreen()
		os.system(command)
	elif (answer == "s" or answer == "S"):
		command = "python ./Git_Source.py"
		clearscreen()
		os.system(command)
	else:
		input("Sorry! Your message couldn't be processed. Hit \"Return\" or \"Enter\" to exit this program: ")
raise SystemExit
