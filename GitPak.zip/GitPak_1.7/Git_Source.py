import os
useros = ""
def clearscreen():
	if (os.name == "windows"):
		os.system("cls")
	elif (os.name == "posix"):
		os.system("clear")
def findos:
	if (os.name == "windows"):
		useros = "w"
	elif (os.name == "posix"):
		useros = "p"
try: input = raw_input
except NameError: pass
answer1 = input("Please specify your username: ")
clearscreen()
answer2 = input("Please specify the repository you want to download: ")
clearscreen()
answer3 = input("Please specify the branch of your source. Leave it blank if you don't know what branches are: ")
clearscreen()
if (answer3 == ""):
	answer3 = "master.zip"
findos
if (useros == "w"):
	command = "(new-object System.Net.WebClient).DownloadFile(" + "https://www.github.com/" + answer1 + "/" + answer2 + "/" + answer3 + ", " + "../" + answer3 + ")"
elif (useros == "p"):
	command = "wget " + "https://www.github.com/" + answer1 + "/" + answer2 + "/" + answer3 + " -P .."
clearscreen()
os.system(command)
clearscreen()
input("The download has finished. Hit Enter/Return to exit this program: ")
raise SystemExit
