#include <stdio.h>
#include <stdlib.h>
int main() {
	int i = 1;
	int is_prime;
	int t;
	int answer;
	int prime_count = 1;
	printf("Enter n (for nth prime): ");
	scanf("%d", &answer);
	if (answer == 1) {
		printf("\nPrime 1: 2");
		exit(0);
	}
	while(1) {
		i += 2;
		is_prime = 1;
		for (t = 2; t * t <= i; t++) {
			if (i % t == 0) {
				is_prime = 0;
				break;
			}
		}
		if (is_prime == 1) {
			++prime_count;
		}
		if (prime_count == answer) {
			printf("\nPrime %d: %d", prime_count, i);
			break;
		}
	}
	return 0;
}
