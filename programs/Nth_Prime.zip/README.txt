Created by iamunknown2.
Under GPLv3 license.
